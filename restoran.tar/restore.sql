--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.1
-- Dumped by pg_dump version 10.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.territories DROP CONSTRAINT fk_territories_region;
ALTER TABLE ONLY public.products DROP CONSTRAINT fk_products_suppliers;
ALTER TABLE ONLY public.products DROP CONSTRAINT fk_products_categories;
ALTER TABLE ONLY public.orders DROP CONSTRAINT fk_orders_shippers;
ALTER TABLE ONLY public.orders DROP CONSTRAINT fk_orders_employees;
ALTER TABLE ONLY public.orders DROP CONSTRAINT fk_orders_customers;
ALTER TABLE ONLY public.order_details DROP CONSTRAINT fk_order_details_products;
ALTER TABLE ONLY public.order_details DROP CONSTRAINT fk_order_details_orders;
ALTER TABLE ONLY public.employees DROP CONSTRAINT fk_employees_employees;
ALTER TABLE ONLY public.employee_territories DROP CONSTRAINT fk_employee_territories_territories;
ALTER TABLE ONLY public.employee_territories DROP CONSTRAINT fk_employee_territories_employees;
ALTER TABLE ONLY public.customer_customer_demo DROP CONSTRAINT fk_customer_customer_demo_customers;
ALTER TABLE ONLY public.customer_customer_demo DROP CONSTRAINT fk_customer_customer_demo_customer_demographics;
ALTER TABLE ONLY public.tb_user DROP CONSTRAINT tb_user_pkey;
ALTER TABLE ONLY public.tb_transaksi DROP CONSTRAINT tb_transaksi_pkey;
ALTER TABLE ONLY public.tb_order DROP CONSTRAINT tb_order_pkey;
ALTER TABLE ONLY public.us_states DROP CONSTRAINT pk_usstates;
ALTER TABLE ONLY public.territories DROP CONSTRAINT pk_territories;
ALTER TABLE ONLY public.suppliers DROP CONSTRAINT pk_suppliers;
ALTER TABLE ONLY public.shippers DROP CONSTRAINT pk_shippers;
ALTER TABLE ONLY public.region DROP CONSTRAINT pk_region;
ALTER TABLE ONLY public.products DROP CONSTRAINT pk_products;
ALTER TABLE ONLY public.orders DROP CONSTRAINT pk_orders;
ALTER TABLE ONLY public.order_details DROP CONSTRAINT pk_order_details;
ALTER TABLE ONLY public.employees DROP CONSTRAINT pk_employees;
ALTER TABLE ONLY public.employee_territories DROP CONSTRAINT pk_employee_territories;
ALTER TABLE ONLY public.customers DROP CONSTRAINT pk_customers;
ALTER TABLE ONLY public.customer_demographics DROP CONSTRAINT pk_customer_demographics;
ALTER TABLE ONLY public.customer_customer_demo DROP CONSTRAINT pk_customer_customer_demo;
ALTER TABLE ONLY public.categories DROP CONSTRAINT pk_categories;
DROP TABLE public.us_states;
DROP TABLE public.territories;
DROP TABLE public.tb_user;
DROP TABLE public.tb_transaksi;
DROP TABLE public.tb_order;
DROP TABLE public.tb_masakan;
DROP TABLE public.tb_level;
DROP TABLE public.suppliers;
DROP TABLE public.shippers;
DROP TABLE public.region;
DROP TABLE public.products;
DROP TABLE public.orders;
DROP TABLE public.order_details;
DROP TABLE public.employees;
DROP TABLE public.employee_territories;
DROP TABLE public.detail_order;
DROP TABLE public.customers;
DROP TABLE public.customer_demographics;
DROP TABLE public.customer_customer_demo;
DROP TABLE public.categories;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE categories (
    category_id smallint NOT NULL,
    category_name character varying(15) NOT NULL,
    description text,
    picture bytea
);


ALTER TABLE categories OWNER TO postgres;

--
-- Name: customer_customer_demo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE customer_customer_demo (
    customer_id bpchar NOT NULL,
    customer_type_id bpchar NOT NULL
);


ALTER TABLE customer_customer_demo OWNER TO postgres;

--
-- Name: customer_demographics; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE customer_demographics (
    customer_type_id bpchar NOT NULL,
    customer_desc text
);


ALTER TABLE customer_demographics OWNER TO postgres;

--
-- Name: customers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE customers (
    customer_id bpchar NOT NULL,
    company_name character varying(40) NOT NULL,
    contact_name character varying(30),
    contact_title character varying(30),
    address character varying(60),
    city character varying(15),
    region character varying(15),
    postal_code character varying(10),
    country character varying(15),
    phone character varying(24),
    fax character varying(24)
);


ALTER TABLE customers OWNER TO postgres;

--
-- Name: detail_order; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE detail_order (
    id_detail_order character varying(12),
    id_order character varying(12),
    id_masakan character varying(12),
    keterangan character varying(100),
    status_detail_order character varying(12)
);


ALTER TABLE detail_order OWNER TO postgres;

--
-- Name: employee_territories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE employee_territories (
    employee_id smallint NOT NULL,
    territory_id character varying(20) NOT NULL
);


ALTER TABLE employee_territories OWNER TO postgres;

--
-- Name: employees; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE employees (
    employee_id smallint NOT NULL,
    last_name character varying(20) NOT NULL,
    first_name character varying(10) NOT NULL,
    title character varying(30),
    title_of_courtesy character varying(25),
    birth_date date,
    hire_date date,
    address character varying(60),
    city character varying(15),
    region character varying(15),
    postal_code character varying(10),
    country character varying(15),
    home_phone character varying(24),
    extension character varying(4),
    photo bytea,
    notes text,
    reports_to smallint,
    photo_path character varying(255)
);


ALTER TABLE employees OWNER TO postgres;

--
-- Name: order_details; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE order_details (
    order_id smallint NOT NULL,
    product_id smallint NOT NULL,
    unit_price real NOT NULL,
    quantity smallint NOT NULL,
    discount real NOT NULL
);


ALTER TABLE order_details OWNER TO postgres;

--
-- Name: orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE orders (
    order_id smallint NOT NULL,
    customer_id bpchar,
    employee_id smallint,
    order_date date,
    required_date date,
    shipped_date date,
    ship_via smallint,
    freight real,
    ship_name character varying(40),
    ship_address character varying(60),
    ship_city character varying(15),
    ship_region character varying(15),
    ship_postal_code character varying(10),
    ship_country character varying(15)
);


ALTER TABLE orders OWNER TO postgres;

--
-- Name: products; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE products (
    product_id smallint NOT NULL,
    product_name character varying(40) NOT NULL,
    supplier_id smallint,
    category_id smallint,
    quantity_per_unit character varying(20),
    unit_price real,
    units_in_stock smallint,
    units_on_order smallint,
    reorder_level smallint,
    discontinued integer NOT NULL
);


ALTER TABLE products OWNER TO postgres;

--
-- Name: region; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE region (
    region_id smallint NOT NULL,
    region_description bpchar NOT NULL
);


ALTER TABLE region OWNER TO postgres;

--
-- Name: shippers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE shippers (
    shipper_id smallint NOT NULL,
    company_name character varying(40) NOT NULL,
    phone character varying(24)
);


ALTER TABLE shippers OWNER TO postgres;

--
-- Name: suppliers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE suppliers (
    supplier_id smallint NOT NULL,
    company_name character varying(40) NOT NULL,
    contact_name character varying(30),
    contact_title character varying(30),
    address character varying(60),
    city character varying(15),
    region character varying(15),
    postal_code character varying(10),
    country character varying(15),
    phone character varying(24),
    fax character varying(24),
    homepage text
);


ALTER TABLE suppliers OWNER TO postgres;

--
-- Name: tb_level; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_level (
    id_level integer,
    nama_level character varying(100)
);


ALTER TABLE tb_level OWNER TO postgres;

--
-- Name: tb_masakan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_masakan (
    id_masakan character varying(12),
    nama_masakan character varying(100),
    harga integer,
    status_masakan character varying(20)
);


ALTER TABLE tb_masakan OWNER TO postgres;

--
-- Name: tb_order; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_order (
    id_order character varying(12) NOT NULL,
    no_meja integer,
    tanggal date,
    id_user character varying(12),
    keterangan character varying(100),
    status_order character varying(100)
);


ALTER TABLE tb_order OWNER TO postgres;

--
-- Name: tb_transaksi; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_transaksi (
    id_transaksi character varying(12) NOT NULL,
    id_user character varying(12),
    id_order character varying(12),
    tanggal date,
    total_bayar integer
);


ALTER TABLE tb_transaksi OWNER TO postgres;

--
-- Name: tb_user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_user (
    id_user character varying(12) NOT NULL,
    username character varying(100),
    password character varying(100),
    nama_user character varying(100),
    id_level integer
);


ALTER TABLE tb_user OWNER TO postgres;

--
-- Name: territories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE territories (
    territory_id character varying(20) NOT NULL,
    territory_description bpchar NOT NULL,
    region_id smallint NOT NULL
);


ALTER TABLE territories OWNER TO postgres;

--
-- Name: us_states; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE us_states (
    state_id smallint NOT NULL,
    state_name character varying(100),
    state_abbr character varying(2),
    state_region character varying(50)
);


ALTER TABLE us_states OWNER TO postgres;

--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY categories (category_id, category_name, description, picture) FROM stdin;
\.
COPY categories (category_id, category_name, description, picture) FROM '$$PATH$$/2927.dat';

--
-- Data for Name: customer_customer_demo; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY customer_customer_demo (customer_id, customer_type_id) FROM stdin;
\.
COPY customer_customer_demo (customer_id, customer_type_id) FROM '$$PATH$$/2928.dat';

--
-- Data for Name: customer_demographics; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY customer_demographics (customer_type_id, customer_desc) FROM stdin;
\.
COPY customer_demographics (customer_type_id, customer_desc) FROM '$$PATH$$/2929.dat';

--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY customers (customer_id, company_name, contact_name, contact_title, address, city, region, postal_code, country, phone, fax) FROM stdin;
\.
COPY customers (customer_id, company_name, contact_name, contact_title, address, city, region, postal_code, country, phone, fax) FROM '$$PATH$$/2930.dat';

--
-- Data for Name: detail_order; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY detail_order (id_detail_order, id_order, id_masakan, keterangan, status_detail_order) FROM stdin;
\.
COPY detail_order (id_detail_order, id_order, id_masakan, keterangan, status_detail_order) FROM '$$PATH$$/2924.dat';

--
-- Data for Name: employee_territories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY employee_territories (employee_id, territory_id) FROM stdin;
\.
COPY employee_territories (employee_id, territory_id) FROM '$$PATH$$/2932.dat';

--
-- Data for Name: employees; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY employees (employee_id, last_name, first_name, title, title_of_courtesy, birth_date, hire_date, address, city, region, postal_code, country, home_phone, extension, photo, notes, reports_to, photo_path) FROM stdin;
\.
COPY employees (employee_id, last_name, first_name, title, title_of_courtesy, birth_date, hire_date, address, city, region, postal_code, country, home_phone, extension, photo, notes, reports_to, photo_path) FROM '$$PATH$$/2931.dat';

--
-- Data for Name: order_details; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY order_details (order_id, product_id, unit_price, quantity, discount) FROM stdin;
\.
COPY order_details (order_id, product_id, unit_price, quantity, discount) FROM '$$PATH$$/2933.dat';

--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY orders (order_id, customer_id, employee_id, order_date, required_date, shipped_date, ship_via, freight, ship_name, ship_address, ship_city, ship_region, ship_postal_code, ship_country) FROM stdin;
\.
COPY orders (order_id, customer_id, employee_id, order_date, required_date, shipped_date, ship_via, freight, ship_name, ship_address, ship_city, ship_region, ship_postal_code, ship_country) FROM '$$PATH$$/2934.dat';

--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY products (product_id, product_name, supplier_id, category_id, quantity_per_unit, unit_price, units_in_stock, units_on_order, reorder_level, discontinued) FROM stdin;
\.
COPY products (product_id, product_name, supplier_id, category_id, quantity_per_unit, unit_price, units_in_stock, units_on_order, reorder_level, discontinued) FROM '$$PATH$$/2935.dat';

--
-- Data for Name: region; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY region (region_id, region_description) FROM stdin;
\.
COPY region (region_id, region_description) FROM '$$PATH$$/2936.dat';

--
-- Data for Name: shippers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY shippers (shipper_id, company_name, phone) FROM stdin;
\.
COPY shippers (shipper_id, company_name, phone) FROM '$$PATH$$/2937.dat';

--
-- Data for Name: suppliers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY suppliers (supplier_id, company_name, contact_name, contact_title, address, city, region, postal_code, country, phone, fax, homepage) FROM stdin;
\.
COPY suppliers (supplier_id, company_name, contact_name, contact_title, address, city, region, postal_code, country, phone, fax, homepage) FROM '$$PATH$$/2938.dat';

--
-- Data for Name: tb_level; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_level (id_level, nama_level) FROM stdin;
\.
COPY tb_level (id_level, nama_level) FROM '$$PATH$$/2923.dat';

--
-- Data for Name: tb_masakan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_masakan (id_masakan, nama_masakan, harga, status_masakan) FROM stdin;
\.
COPY tb_masakan (id_masakan, nama_masakan, harga, status_masakan) FROM '$$PATH$$/2925.dat';

--
-- Data for Name: tb_order; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_order (id_order, no_meja, tanggal, id_user, keterangan, status_order) FROM stdin;
\.
COPY tb_order (id_order, no_meja, tanggal, id_user, keterangan, status_order) FROM '$$PATH$$/2921.dat';

--
-- Data for Name: tb_transaksi; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_transaksi (id_transaksi, id_user, id_order, tanggal, total_bayar) FROM stdin;
\.
COPY tb_transaksi (id_transaksi, id_user, id_order, tanggal, total_bayar) FROM '$$PATH$$/2926.dat';

--
-- Data for Name: tb_user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_user (id_user, username, password, nama_user, id_level) FROM stdin;
\.
COPY tb_user (id_user, username, password, nama_user, id_level) FROM '$$PATH$$/2922.dat';

--
-- Data for Name: territories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY territories (territory_id, territory_description, region_id) FROM stdin;
\.
COPY territories (territory_id, territory_description, region_id) FROM '$$PATH$$/2939.dat';

--
-- Data for Name: us_states; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY us_states (state_id, state_name, state_abbr, state_region) FROM stdin;
\.
COPY us_states (state_id, state_name, state_abbr, state_region) FROM '$$PATH$$/2940.dat';

--
-- Name: categories pk_categories; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY categories
    ADD CONSTRAINT pk_categories PRIMARY KEY (category_id);


--
-- Name: customer_customer_demo pk_customer_customer_demo; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY customer_customer_demo
    ADD CONSTRAINT pk_customer_customer_demo PRIMARY KEY (customer_id, customer_type_id);


--
-- Name: customer_demographics pk_customer_demographics; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY customer_demographics
    ADD CONSTRAINT pk_customer_demographics PRIMARY KEY (customer_type_id);


--
-- Name: customers pk_customers; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY customers
    ADD CONSTRAINT pk_customers PRIMARY KEY (customer_id);


--
-- Name: employee_territories pk_employee_territories; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY employee_territories
    ADD CONSTRAINT pk_employee_territories PRIMARY KEY (employee_id, territory_id);


--
-- Name: employees pk_employees; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY employees
    ADD CONSTRAINT pk_employees PRIMARY KEY (employee_id);


--
-- Name: order_details pk_order_details; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY order_details
    ADD CONSTRAINT pk_order_details PRIMARY KEY (order_id, product_id);


--
-- Name: orders pk_orders; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY orders
    ADD CONSTRAINT pk_orders PRIMARY KEY (order_id);


--
-- Name: products pk_products; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY products
    ADD CONSTRAINT pk_products PRIMARY KEY (product_id);


--
-- Name: region pk_region; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY region
    ADD CONSTRAINT pk_region PRIMARY KEY (region_id);


--
-- Name: shippers pk_shippers; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY shippers
    ADD CONSTRAINT pk_shippers PRIMARY KEY (shipper_id);


--
-- Name: suppliers pk_suppliers; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY suppliers
    ADD CONSTRAINT pk_suppliers PRIMARY KEY (supplier_id);


--
-- Name: territories pk_territories; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY territories
    ADD CONSTRAINT pk_territories PRIMARY KEY (territory_id);


--
-- Name: us_states pk_usstates; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY us_states
    ADD CONSTRAINT pk_usstates PRIMARY KEY (state_id);


--
-- Name: tb_order tb_order_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_order
    ADD CONSTRAINT tb_order_pkey PRIMARY KEY (id_order);


--
-- Name: tb_transaksi tb_transaksi_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_transaksi
    ADD CONSTRAINT tb_transaksi_pkey PRIMARY KEY (id_transaksi);


--
-- Name: tb_user tb_user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_user
    ADD CONSTRAINT tb_user_pkey PRIMARY KEY (id_user);


--
-- Name: customer_customer_demo fk_customer_customer_demo_customer_demographics; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY customer_customer_demo
    ADD CONSTRAINT fk_customer_customer_demo_customer_demographics FOREIGN KEY (customer_type_id) REFERENCES customer_demographics(customer_type_id);


--
-- Name: customer_customer_demo fk_customer_customer_demo_customers; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY customer_customer_demo
    ADD CONSTRAINT fk_customer_customer_demo_customers FOREIGN KEY (customer_id) REFERENCES customers(customer_id);


--
-- Name: employee_territories fk_employee_territories_employees; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY employee_territories
    ADD CONSTRAINT fk_employee_territories_employees FOREIGN KEY (employee_id) REFERENCES employees(employee_id);


--
-- Name: employee_territories fk_employee_territories_territories; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY employee_territories
    ADD CONSTRAINT fk_employee_territories_territories FOREIGN KEY (territory_id) REFERENCES territories(territory_id);


--
-- Name: employees fk_employees_employees; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY employees
    ADD CONSTRAINT fk_employees_employees FOREIGN KEY (reports_to) REFERENCES employees(employee_id);


--
-- Name: order_details fk_order_details_orders; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY order_details
    ADD CONSTRAINT fk_order_details_orders FOREIGN KEY (order_id) REFERENCES orders(order_id);


--
-- Name: order_details fk_order_details_products; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY order_details
    ADD CONSTRAINT fk_order_details_products FOREIGN KEY (product_id) REFERENCES products(product_id);


--
-- Name: orders fk_orders_customers; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY orders
    ADD CONSTRAINT fk_orders_customers FOREIGN KEY (customer_id) REFERENCES customers(customer_id);


--
-- Name: orders fk_orders_employees; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY orders
    ADD CONSTRAINT fk_orders_employees FOREIGN KEY (employee_id) REFERENCES employees(employee_id);


--
-- Name: orders fk_orders_shippers; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY orders
    ADD CONSTRAINT fk_orders_shippers FOREIGN KEY (ship_via) REFERENCES shippers(shipper_id);


--
-- Name: products fk_products_categories; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY products
    ADD CONSTRAINT fk_products_categories FOREIGN KEY (category_id) REFERENCES categories(category_id);


--
-- Name: products fk_products_suppliers; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY products
    ADD CONSTRAINT fk_products_suppliers FOREIGN KEY (supplier_id) REFERENCES suppliers(supplier_id);


--
-- Name: territories fk_territories_region; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY territories
    ADD CONSTRAINT fk_territories_region FOREIGN KEY (region_id) REFERENCES region(region_id);


--
-- PostgreSQL database dump complete
--

